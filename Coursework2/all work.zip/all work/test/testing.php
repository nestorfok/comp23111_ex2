<?php
	require_once('../test/config.php');
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<?php
		$x =1;
    	echo "<?php
    		if ($x==1){
    			echo 'hi';
    		}

    	?>";
    	
    ?>
</body>
</html>